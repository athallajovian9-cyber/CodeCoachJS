@echo off
setlocal
cd /d "%~dp0"
python gui.py
pause
